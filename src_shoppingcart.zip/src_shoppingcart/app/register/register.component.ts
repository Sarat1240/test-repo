import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { environment } from 'src/environments/environment';
import {FormGroup,FormControl, Validators  } from '@angular/forms';
import { DataService } from '../service/api/data.service';
import { Router } from '@angular/router';
import { Users } from '../models/users-model';
/**
  * @description This component deals with resitering an user
  */
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm:FormGroup;
  submitted:boolean =false;
  user :any = {
    firstName:'',
    mobileNumber:'',
    address:'',
    email:'',
    password:''
  }
  baseUrl:string=`${environment.baseUrl}/shoppingUsers`;
  //emailPattern:string ="[A-Za-z0-9._%+-]*()";
  mobileNumberPattern:string= "^(\\+91)[0-9]{10}$";
  passwordPattern:string= "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@&]).{8,12}$";
  
  constructor(private dataService:DataService,private route:Router) { }
  /**
  * @description This method adds  validators  the form
  */
  ngOnInit(): void {
    this.registerForm = new FormGroup(
      {
        firstName: new FormControl('',[Validators.required,Validators.minLength(3)]),
        email: new FormControl('',Validators.required),
        mobileNumber: new FormControl('',[Validators.required,Validators.pattern(this.mobileNumberPattern)]),
        address: new FormControl('',[Validators.required,Validators.maxLength(100)]),
        password: new FormControl('',[Validators.required,Validators.minLength(8),Validators.maxLength(12),Validators.pattern(this.passwordPattern)]),
        confirmPassword: new FormControl('',Validators.required)
      }
    )
  }

  /**
  * @description This method validates the form, and upon successful validation calls a method to register user
  */
  submit=()=>
  {
    this.submitted = true;
    if(this.registerForm.valid)
    {
      this.user = {firstName:this.registerForm.controls.firstName.value,email:this.registerForm.controls.email.value,
        mobileNumber:this.registerForm.controls.mobileNumber.value,address:this.registerForm.controls.address.value,password:this.registerForm.controls.password.value};
      this.addUser(this.user);
    }
  }

  /**
  * @description This method registers an user
  * @param user
  */
  addUser=(user)=>
  {
    this.dataService.addData(`${this.baseUrl}`,user).subscribe((response:Users)=>{
      console.log(response);   
      alert("User added successfully")
      this.route.navigate(['/login']);   
    },
    (error)=>{
      console.log(error);
    },
    ()=>{

    })
  }



}