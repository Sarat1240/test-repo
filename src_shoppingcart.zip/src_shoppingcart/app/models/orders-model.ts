export interface Orders{

    // userEmail:string;
    // totalProducts:Array<any>=[
    //      productName

    
    // ];
}