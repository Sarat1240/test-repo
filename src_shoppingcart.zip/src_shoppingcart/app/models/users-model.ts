export interface Users
{
    address:string;
    email:string;
    firstName:string;
    id:number;
    mobileNumber:string;
    password:string;
}