export interface LoginDetails
{
    email:string;
    password:string;
}