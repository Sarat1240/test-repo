export interface Product
{
    productName:string;
    price:number;
    description:string;
    rating:number
}