import { Component, OnInit } from '@angular/core';
import { DataService } from '../service/api/data.service';
import { environment } from 'src/environments/environment';
/**
  * @description This component has method that fecth previous orders for an user
  */
@Component({
  selector: 'app-my-orders',
  templateUrl: './my-orders.component.html',
  styleUrls: ['./my-orders.component.css']
})
export class MyOrdersComponent implements OnInit {

  orders: any = [];
  ordersBaseUrl: string = `${environment.baseUrl}/orders`;

  constructor(private dataService:DataService) { }

  /**
  * @description This method calls a method that fetch previous orders for an user
  */
  ngOnInit(): void {
    this.getOrders();
  }

  /**
  * @description This method fetches all the orders for user by calling service method
  */
 getOrders = () => {
    this.dataService.getDataByUser(this.ordersBaseUrl,sessionStorage.getItem('email')).subscribe((response) => {
      this.orders = response;
    },
      (error) => {
        console.log(error);
      },
      () => {

      })
  }

}
