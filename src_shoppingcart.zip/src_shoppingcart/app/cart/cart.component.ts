import { Component, OnInit } from '@angular/core';
import { DataService } from '../service/api/data.service';

/**
* @description This component has methods that shows products added to cart and can also delete cart items and update quantity
*/
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})

export class CartComponent implements OnInit {

  cartItems:Array<any>=[];
  constructor(private dataService: DataService) { }

  ngOnInit(): void {
    this.displayData();
  }
  /**
  * @description This method displays cart items
  */
  displayData=()=>
  {
    var len = sessionStorage.length;
    for(let i=0; i<len; i++) 
    {
       // debugger
        let key = sessionStorage.key(i);
        
        if(key!=="email")
        {
            let jsonobj = sessionStorage.getItem(key);
            let data = JSON.parse(jsonobj);
            let id = data.id;
            let productName = data.productName;
            let price = data.price;
            let description =data.description;
            let quantity = data.quantity;
          
          this.cartItems.push({id,productName,price,description,quantity});
          
        }    
    }
  }
  /**
  * @description This method deletes a product from the cart
  * @param id
  */
  deleteProduct=(id)=>
  {
    let result = confirm("Are you sure do you want to delete selected cart item?");
    if(result===true)
    {
      sessionStorage.removeItem(id);
      this.cartItems.splice(0,sessionStorage.length);
      this.displayData();
    }
  }

  /**
  * @description This method updates quantity of a product in the cart
  * @param id
  * @param qty
  */
  updateProduct=(id,qty)=>
  {
      if(qty.value<=0)
      {
          alert("You should select atleast one product to add product to cart");
          return;
      }
      let cartItem = JSON.parse(sessionStorage.getItem(id));
      cartItem.quantity=qty.value;
      sessionStorage.setItem(id,JSON.stringify(cartItem));
      this.cartItems.splice(0,sessionStorage.length);      
      alert("Quantity for the selected product updated successfully");
      this.displayData();    
  }

   /* This function attaches the product list data to DOM and render only the new changes */
   trackById = (index: number, cart: any) => {
    return cart.id;
  }

}
