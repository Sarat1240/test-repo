import { Component, OnInit, Input, OnChanges } from '@angular/core';
import {SimpleChanges} from '@angular/core';
import { Router } from '@angular/router';


/**
  * @description This component displays application header and can logout of the application
  */
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  loginStatus :boolean = false;
  email:string=null;
  constructor(private route:Router) {
    
   }

  /**
  * @description This method saves the email of user
  */
  ngOnInit(): void {
    if(sessionStorage.getItem("email")!==null)
    {
      this.loginStatus = true;
      this.email=sessionStorage.getItem("email");
    }
    
   
  }
  /**
  * @description This method logs out user from the application
  */
  logout():void{
    sessionStorage.clear();
    this.loginStatus = false;
    this.email=null;
    this.route.navigate(['/login']);
  }
  

}
