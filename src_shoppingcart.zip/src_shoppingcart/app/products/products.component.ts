import { Component, OnInit } from '@angular/core';
import { DataService } from '../service/api/data.service';
import { environment } from 'src/environments/environment';
import { Product } from '../models/products-model';
import { Router } from '@angular/router';

/**
* @description This component has methods that fetches all products, adding products to cart,placing an order
*/
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  products: any = [];
  totalProducts:Array<any>=[];
  cartItems:any={
    userEmail:'',
    totalProducts:'',
    OrderDate:''
  }
  // productName:string;
  // userEmail:string;
  // price:number;
  // quantity:number;
  // totalPrice:number;
  // orderDate:Date;

  selectedProductData: any = {
  };

  baseUrl: string = `${environment.baseUrl}/products`;
  ordersBaseUrl: string = `${environment.baseUrl}/orders`;

  constructor(private dataService: DataService,private route:Router) { }

  /**
  * @description This method calls a method that fetches all products by calling service method
  */
  ngOnInit(): void {
    this.getProducts();
  }
  /**
  * @description This method fetches all products by calling service method
  */
 getProducts = () => {
  this.dataService.getData(this.baseUrl).subscribe((response:Product) => {
    this.products = response;
  },
    (error) => {
      console.log(error);
    },
    () => {

    })
  }
  /**
  * @description This method adds a product to cart
  * @param i
  * @param quantity
  */
  addToCart(i:number,quantity:number)
  {
    if(quantity<=0)
    {
        alert("Quantity should be greater than Zero to add product to cart.");
        return;
    }
    let prd = this.products[i];
    this.selectedProductData={id:prd.id,productName:prd.productName,description:prd.description,price:prd.price,rating:prd.rating,quantity:quantity};
    sessionStorage.setItem(prd.id,JSON.stringify(this.selectedProductData));
    alert("Product successfully added to the cart!");
  }
  /**
  * @description This method initiates an order
  */
  placeOrder=()=>
  {
    if(sessionStorage.getItem("email")===null)
    {
      alert("Please login to place an order");
      this.route.navigate(['/login']);
    }
    else
    {
      let len = sessionStorage.length;
      if(len===1)
      {
        alert("No items present in cart to order");
      }
      else
      {
        for(let i=0;i<sessionStorage.length;i++)
        {
          let key = sessionStorage.key(i);
          
          if(key!=="email")
          {
            let value = sessionStorage.getItem(key);
            let data  = JSON.parse(value)
            let cartData = {productName:data.productName,price:data.price,quantity:data.quantity,totalPrice:data.price*data.quantity,orderDate:new Date()};
            this.totalProducts.push(cartData);
          }
        }
        this.cartItems={
          userEmail:sessionStorage.getItem("email"),
          totalProducts:this.totalProducts,
          OrderDate:new Date()
        }
        this.dataService.addData(`${this.ordersBaseUrl}`, this.cartItems).subscribe((response) => {
          console.log("After placing order:"+response.toString());
          alert("Order has been placed successfully ");
        },
          (error) => {
            console.log(error);
          },
          () => {
    
          })
      }
    }
    if(sessionStorage.getItem("email")!==null)
    {
        for(var i=sessionStorage.length; i>=0; i--) 
        {
          //debugger
            var key = sessionStorage.key(i);
            
            if(key!="email")
            {
                sessionStorage.removeItem(key);
            }
        }
    }
  }
 
}
