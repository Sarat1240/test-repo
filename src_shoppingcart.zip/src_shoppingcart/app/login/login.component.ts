import { Component, OnInit, OnDestroy } from '@angular/core';
import { environment } from 'src/environments/environment';
import { DataService } from '../service/api/data.service';
import { Router } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { LoginDetails } from '../models/loginDetails-model';
import { Subscription } from 'rxjs/internal/Subscription';

/**
  * @description This component deals with logging user into the application
  */
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  baseUrl:string=`${environment.baseUrl}/shoppingUsers`;
  private subscription:Subscription;

  model:LoginDetails={
    email:'',
    password:''
  }
  
  submitted = false;

  constructor(private dataService:DataService,private route:Router) { }


  ngOnInit(): void {
  }
 /**
  * @description This method validates user login by calling userLogin method
  * @param loginRef
  */
  submit = (loginRef) =>
  {
    this.submitted = true;
    if(loginRef.valid)
      {
         this.loginUser();
      }
  }

  /**
  * @description When login button clicked, this method validates user login
  */
  loginUser=()=>
  {
   this.subscription  = this.dataService.validateLogin(this.baseUrl,this.model.email,this.model.password)
    .subscribe((response:Array<any>)=>{
      sessionStorage.setItem("email",this.model.email);
      let responseArrayLength = response.length;
      if(responseArrayLength===1)
      {
          this.route.navigate(['/products']);
      }
      else
      {      
          alert("Invalid Credentials!");
      }
    },
    (error)=>{
 
    },
    ()=>{

    })
  }

  ngOnDestroy(): void {    
    console.log("In ngOnDestroy:",this.subscription);
    this.subscription.unsubscribe();    
}

 

}
